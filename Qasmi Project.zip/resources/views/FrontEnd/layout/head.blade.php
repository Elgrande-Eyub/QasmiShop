
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="{{ asset('assets/imgs/theme/logo.ico') }}">
    <!-- Template CSS -->
    <link rel="stylesheet" href="{{ asset('assets/css/mainc619.css?v=1.0') }}">

