<?php return array (
  'cart' => 'App\\Http\\Livewire\\Cart',
);